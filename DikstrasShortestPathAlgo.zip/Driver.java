/**
 * 
 * @author The_Cako_Field_Feel_The_Force
 * * Chris Thompson cgt@bu.edu
 * Lawrence Field lfield@bu.edu, cascia1987@gmail.com
 * In class Lab
 * Dykstras Shortest Path Algo
 */

/*
* Nodes with edges and lengths
	 * Node 
	 * 	count
	 *  cost/distance/some variable
	 * 
	 *Dynamic Linked List Queue
	 *Starting point given by V0
	 *V0 is placed in the queue
	 *V0 edges and costs are determined
	 *edge costs are compared
	 *this places the lowest costs queues on first in ascending order
	 *
	 *add the values of the cost of edges between the nodes and compare to the all ready existing value
	 *
	 *From the starting point all the values to go to every attainable node will be determined by the shorted cost
	 * 
	 * 
	
 Foreach node set distance[node] = HIGH
SettledNodes = empty
UnSettledNodes = empty

Add sourceNode to UnSettledNodes
distance[sourceNode]= 0

while (UnSettledNodes is not empty) {
  evaluationNode = getNodeWithLowestDistance(UnSettledNodes)
  remove evaluationNode from UnSettledNodes 
    add evaluationNode to SettledNodes
    evaluatedNeighbors(evaluationNode)
}

getNodeWithLowestDistance(UnSettledNodes){
  find the node with the lowest distance in UnSettledNodes and return it 
}

evaluatedNeighbors(evaluationNode){
  Foreach destinationNode which can be reached via an edge from evaluationNode AND which is not in SettledNodes {
    edgeDistance = getDistance(edge(evaluationNode, destinationNode))
    newDistance = distance[evaluationNode] + edgeDistance
    if (distance[destinationNode]  > newDistance) {
      distance[destinationNode]  = newDistance 
      add destinationNode to UnSettledNodes
    }
    
  }
	 */
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Driver me = new Driver();
		me.doIt();
	}
	
	public void doIt(){
		
		TestDijkstraAlgorithm dik = new TestDijkstraAlgorithm();
		dik.execute();
	}

}
