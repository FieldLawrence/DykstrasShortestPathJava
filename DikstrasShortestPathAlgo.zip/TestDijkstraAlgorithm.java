import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class TestDijkstraAlgorithm {
	private List<Vertex> nodes;
	  private List<Edge> edges;

	  
	  public void execute() {
	    nodes = new ArrayList<Vertex>();
	    edges = new ArrayList<Edge>();
	    for (int i = 0; i < 9; i++) {
	      Vertex location = new Vertex("Node_" + i, "Node_" + i);
	      nodes.add(location);
	    }

	    addLane("Edge_0", 0, 1, 5);
	    addLane("Edge_1", 0, 2, 2);
	    addLane("Edge_2", 0, 5, 5);
	    addLane("Edge_3", 1, 4, 2);
	    addLane("Edge_4", 1, 5, 4);
	    addLane("Edge_5", 2, 4, 3);
	    addLane("Edge_6", 3, 2, 3);
	    addLane("Edge_7", 3, 6, 4);
	    addLane("Edge_8", 4, 6, 2);
	    addLane("Edge_9", 5, 6, 3);
	    

	    // Lets check from location Loc_1 to Loc_10
	    Graph graph = new Graph(nodes, edges);
	    DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(graph);
	    dijkstra.execute(nodes.get(0));
	    //LinkedList<Vertex> path = dijkstra.getPath(nodes.get(1));
	    //LinkedList<Vertex> path2 = dijkstra.getPath(nodes.get(2));
	   // LinkedList<Vertex> path3 = dijkstra.getPath(nodes.get(3));
	    //LinkedList<Vertex> path4 = dijkstra.getPath(nodes.get(4));
	    //LinkedList<Vertex> path5 = dijkstra.getPath(nodes.get(5));
	    LinkedList<Vertex> path6 = dijkstra.getPath(nodes.get(6));
	    
	   
	    
	    //for (Vertex vertex : path) {
	     // System.out.println(vertex);
	    //}
	    
	   // for (Vertex vertex : path2) {
		    //  System.out.println(vertex);
		  //  }
	   // for (Vertex vertex : path3) {
		 //     System.out.println(vertex);
		   // }
	   // for (Vertex vertex : path4) {
		     // System.out.println(vertex);
		    //}
	    //for (Vertex vertex : path5) {
		  //    System.out.println(vertex);
		    //}
	    for (Vertex vertex : path6) {
		      System.out.println(vertex);
		    }
	    
	  }

	  private void addLane(String laneId, int sourceLocNo, int destLocNo,
	      int duration) {
	    Edge lane = new Edge(laneId,nodes.get(sourceLocNo), nodes.get(destLocNo), duration);
	    edges.add(lane);
	  }
}
